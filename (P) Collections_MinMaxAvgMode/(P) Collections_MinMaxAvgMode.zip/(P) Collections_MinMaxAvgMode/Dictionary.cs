﻿namespace _P__Collections_MinMaxAvgMode
{
    internal class Dictionary<T>
    {
    }
}